import bcrypt from 'bcryptjs';
import { query } from '../config/database.js';
import { generateToken } from '../utils/jwt.js';
import { logActivity } from '../utils/logger.js';

// ลงทะเบียน
export const register = async (req, res) => {
  // ... (โค้ดส่วน register เหมือนเดิม) ...
  try {
    const { username, email, password, phone, role = 'member' } = req.body;

    // Validation
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกข้อมูลให้ครบถ้วน'
      });
    }

    // ตรวจสอบว่า email หรือ username ซ้ำหรือไม่
    // --- MODIFIED ---: ตรวจสอบเฉพาะ is_active = 1
    const existing = await query(
      'SELECT email, username FROM users WHERE (email = ? OR username = ?) AND is_active = 1',
      [email, username]
    );

    if (existing.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'อีเมลหรือชื่อผู้ใช้นี้มีในระบบแล้ว'
      });
    }

    // --- ADDED ---: ตรวจสอบเบอร์โทรศัพท์ซ้ำ (ถ้ามีการกรอกเบอร์มา)
    if (phone) {
      const phoneExists = await query(
        'SELECT phone FROM users WHERE phone = ? AND is_active = 1',
        [phone]
      );

      if (phoneExists.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'เบอร์โทรศัพท์นี้มีในระบบแล้ว'
        });
      }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user
    // (is_active จะเป็น 1 โดย default จากฐานข้อมูล)
    const result = await query(
      `INSERT INTO users (username, email, password_hash, phone, role) 
       VALUES (?, ?, ?, ?, ?)`,
      [username, email, hashedPassword, phone, role]
    );

    // Log activity
    await logActivity(result.insertId, 'USER_REGISTER', 'users', result.insertId);

    res.status(201).json({
      success: true,
      message: 'ลงทะเบียนสำเร็จ',
      data: {
        userId: result.insertId,
        username,
        email,
        role
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการลงทะเบียน',
      error: error.message
    });
  }
};

// เข้าสู่ระบบ
// เข้าสู่ระบบ
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกอีเมลและรหัสผ่าน'
      });
    }

    // ค้นหา user (ดึง profile_image และ is_active ด้วย)
    const users = await query(
      'SELECT user_id, username, email, password_hash, phone, role, profile_image, is_active FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
      });
    }

    const user = users[0];

    // ตรวจสอบว่าบัญชีถูกปิดการใช้งานหรือไม่
    if (user.is_active === 0) {
      return res.status(403).json({
        success: false,
        message: 'บัญชีนี้ถูกปิดการใช้งาน กรุณาติดต่อผู้ดูแล'
      });
    }

    // ตรวจสอบรหัสผ่าน
    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
      });
    }

    // สร้าง JWT token
    const token = generateToken({
      userId: user.user_id,
      email: user.email,
      role: user.role
    });

    // Log activity
    await logActivity(user.user_id, 'USER_LOGIN', 'users', user.user_id);

    // ตั้งค่า Cookie (สำหรับ Browser)
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 1000 * 60 * 60 * 24 * 7 // 7 วัน
    });

    // 🆕 ส่ง Response (เพิ่ม token ใน body สำหรับ Postman/API)
    res.json({
      success: true,
      message: 'เข้าสู่ระบบสำเร็จ',
      token: token, // ← เพิ่มบรรทัดนี้
      data: {
        user: {
          userId: user.user_id,
          username: user.username,
          email: user.email,
          role: user.role,
          phone: user.phone,
          profile_image: user.profile_image
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ',
      error: error.message
    });
  }
};

// 🔽 === เพิ่มฟังก์ชันนี้ === 🔽
// ออกจากระบบ
export const logout = (req, res) => {
  try {
    // เคลียร์ Cookie 'token' โดยการตั้งค่าให้หมดอายุทันที
    res.cookie('token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      expires: new Date(0), // ตั้งเวลาหมดอายุในอดีต
    });

    res.status(200).json({
      success: true,
      message: 'ออกจากระบบสำเร็จ',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการออกจากระบบ',
      error: error.message,
    });
  }
};
// 🔼 === สิ้นสุดส่วนที่เพิ่ม === 🔼

// ดึงข้อมูลตัวเอง
export const getMe = async (req, res) => {
  // ... (โค้ดส่วน getMe เหมือนเดิม) ...
  try {
    // --- ADDED ---: ตรวจสอบว่า user ยัง active อยู่หรือไม่
    // (req.user มาจาก middleware auth.js)
    if (req.user.is_active === 0) {
       return res.status(403).json({
        success: false,
        message: 'บัญชีนี้ถูกปิดการใช้งานแล้ว'
      });
    }
    
    res.json({
      success: true,
      data: req.user
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาด',
      error: error.message
    });
  }
};

// เปลี่ยนรหัสผ่าน
// export const changePassword = async (req, res) => {
//   // ... (โค้ดส่วน changePassword เหมือนเดิม) ...
//   try {
//     const { oldPassword, newPassword } = req.body;
//     const userId = req.user.user_id;

//     if (!oldPassword || !newPassword) {
//       return res.status(400).json({
//         success: false,
//         message: 'กรุณากรอกข้อมูลให้ครบถ้วน'
//       });
//     }

//     // ดึงข้อมูล user
//     // --- MODIFIED ---: ตรวจสอบ is_active ด้วย
//     const users = await query(
//       'SELECT password_hash, is_active FROM users WHERE user_id = ?',
//       [userId]
//     );

//     if (users.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: 'ไม่พบข้อมูลผู้ใช้'
//       });
//     }
    
//     // --- ADDED ---: ตรวจสอบสถานะ
//     if (users[0].is_active === 0) {
//       return res.status(403).json({
//         success: false,
//         message: 'บัญชีนี้ถูกปิดการใช้งาน'
//       });
//     }

//     // ตรวจสอบรหัสผ่านเก่า
//     const isMatch = await bcrypt.compare(oldPassword, users[0].password_hash);

//     if (!isMatch) {
//       return res.status(400).json({
//         success: false,
//         message: 'รหัสผ่านเก่าไม่ถูกต้อง'
//       });
//     }

//     // Hash รหัสผ่านใหม่
//     const hashedPassword = await bcrypt.hash(newPassword, 10);

//     // Update password
//     await query(
//       'UPDATE users SET password_hash = ? WHERE user_id = ?',
//       [hashedPassword, userId]
//     );

//     // Log activity
//     await logActivity(userId, 'CHANGE_PASSWORD', 'users', userId);

//     res.json({
//       success: true,
//       message: 'เปลี่ยนรหัสผ่านสำเร็จ'
//     });
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: 'เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน',
//       error: error.message
//     });
//   }
// };